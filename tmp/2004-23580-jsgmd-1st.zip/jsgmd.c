/****************************************************************************
 * 4541.681A Genetic Algorithm (2005/Spring) �����͹���                     *
 * 2004-23580  Jaeho Shin <netj@ropas.snu.ac.kr>                            *
 * Created: 2005-04-26                                                      *
 ****************************************************************************/

#ifndef A
#define A 1
#endif
#ifndef B
#define B 4
#endif
#ifndef T
#define T 1800
#endif

#define P 1000
#define K (P * 1 / 10)
#define SELPRESS 3
#define XOVER_CUTS 2 //(2 * (N / 54 + 1))

#define POPFUB 2.5
#define MUTRATE ((fbest / abs(fbest - fsum / P) > POPFUB) ? 1 : 0)
#define HEXSPINRATE ((int)(fbest / abs(fbest - fsum / P) / POPFUB))

#if (T == 0)
#define DONE (generations > P * 100 || gbestrepeated > P * 10 || var0cnt > 0)
#else
#define DONE (var0cnt > 0)
#endif


#if A>B
#error "A must be less than or equal to B"
#endif

#define SUM(n) ((n)*((n)+1)/2)
#define M (2*(SUM(B-1) - SUM(A-1)) + B)
#define N (4*(SUM(B) - SUM(A-1)) + 2*(B-A+1))

#ifdef DEBUG
#define debug(fmt...) fprintf(stderr, "## " fmt)
#else
#define debug(fmt...)
#endif
#define message(fmt...) fprintf(stderr, "# " fmt)


#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <math.h>


typedef short idx_t;
typedef short gene;
typedef gene *chromo;
typedef chromo *population;
typedef double fitness_t;

population pop;
int generations = 0,
    gbestrepeated = 0;
fitness_t gbest;

int parent1[K], parent2[K];
chromo offspring[K];

fitness_t popf[P], popmean[P], popvar[P],
          fbest = -1.0/0.0, fworst, fsum = 0, meansum = 0, varsum = 0,
          fbestmean, fbestvar, ffsum;
int fbestidx = 0,
    var0idx = -1, var0cnt = 0;

#define rnd_one() \
    (((double)rand())/((double)RAND_MAX + 1.0))
#define rnd_f(ub) ((double)(ub) * ((rnd_one() + rnd_one()) / 2.0))
#define rnd(n) ((unsigned int)rnd_f(n))
#define min(a, b) (((a) < (b)) ? (a) : (b))
#define max(a, b) (((a) > (b)) ? (a) : (b))

void error(char *msg) {
    fprintf(stderr, "error: %s\n", msg);
    exit(4);
}


/****************************************************************************
 * Hexagon Structure                                                        *
 ****************************************************************************/

/*
    NOTE: Following variables must be defined within the scope.
          idx_t i,j,C; char L,H;
*/
#define for_each_i \
for (C=A, i=0, \
        L = (i < B-A) ? 1 : 0, \
        H = (i > B-A) ? 1 : 0; \
        i<=2*(B-A); \
        C += L ? +1 : -1, i++, \
        L = (i < B-A) ? 1 : 0, \
        H = (i > B-A) ? 1 : 0  \
    )
#define for_each_j \
    for (j=0; j<C; j++)
#define for_each_ij for_each_i for_each_j


idx_t idx[(2*(B-A)+1)][B][6];

void fill_idx() {
    /* prepare idx for gene # assignment */
    int k;
    idx_t i,j,C; char L,H;
    for_each_ij {
        for (k=0; k<6; k++)
            idx[i][j][k] = N+1;
    }
    int gene_idx_cnt = 0;
#ifdef ENCODING_RANDOM
    int gene_idx[N];
    for (i=0; i<N; i++)
        gene_idx[i] = 0;
    int next_gene_idx() {
        int c = rnd(N - gene_idx_cnt--);
        int i = rnd(N);
        while (c >= 0) {
            while (gene_idx[i])
                i = (i+1) % N;
            c--;
        }
        gene_idx[i] = 1;
        return i;
    }
#else
#define next_gene_idx()  gene_idx_cnt++
    // TODO: must be a better encoding
#endif
    /* assign gene indexes */
    for_each_ij {
#define assign_if_exists(ii, id, jj, k) \
        if (0<=ii && ii<=2*(B-A) && 0<=jj && jj<C + id * (L ? 1 : H ? -1 : -id)) \
            idx[ii][jj][k] = gene_idx
#define share(k, i1, j1, k1, i2, j2, k2) \
        if (idx[i][j][k] > N) { \
            int gene_idx = next_gene_idx(); \
            idx[i][j][k] = gene_idx; \
            assign_if_exists(i+i1, i1, j+j1, k1); \
            assign_if_exists(i+i2, i2, j+j2, k2); \
        }
        share(0,  -1, -1+H, 4,  00, -1+0, 2);
        share(1,  -1, 00+H, 2,  -1, -1+H, 3);
        share(2,  00, +1+0, 0,  -1, 00+H, 4);
        share(3,  +1, 00+L, 1,  00, +1+0, 5);
        share(4,  +1, -1+L, 2,  +1, 00+L, 0);
        share(5,  00, -1+0, 3,  +1, -1+L, 1);
    }
}

void print_chromo(FILE *out, chromo c) {
    idx_t i, j, C; char L, H;
#define print(fmt...) fprintf(out, fmt)
#define indent() for (j=C; j<B; j++) print("    ");
    for (C=A, i=0; C<=B; C++, i++) {
        indent(); for_each_j print("    %3d ", c[idx[i][j][1]]); print("\n");
        indent(); for_each_j print("%3d     ", c[idx[i][j][0]]);
        print("%3d\n", c[idx[i][j-1][2]]);
    }
    for (C=B, i=B-A; C>=A; C--, i++) {
        indent(); for_each_j print("%3d     ", c[idx[i][j][5]]);
        print("%3d\n", c[idx[i][j-1][3]]);
        indent(); for_each_j print("    %3d ", c[idx[i][j][4]]); print("\n");
    }
    print("\n");
#undef print
#undef indent
#undef print1
#undef print0
}

inline int hexsum(chromo c, idx_t i, idx_t j) {
    int s = 0;
    int k;
    idx_t *ij = idx[i][j];
    for (k=0; k<6; k++)
        s += c[ij[k]];
    return s;
}



/****************************************************************************
 * Operators for Genetic Algorithm                                          *
 ****************************************************************************/
#define new_chromosome() malloc(N * sizeof(gene))
#define copy_chromosome(dest, src) \
    memcpy(dest, src, N * sizeof(gene))

void xover(chromo p1, chromo p2, chromo o) {
    // FIXME: don't use d.  use (N - i) for more uniform randomness
    idx_t i = 0, j, c = XOVER_CUTS, d = N / XOVER_CUTS;
    chromo p = p1;
    while (c > 0) {
        for (j=i, i+= rnd(d); j<=i; j++)
            o[j] = p[j];
        c--;
        i++;
        p = (p == p1) ? p2 : p1;
    }
    for (; i<N; i++)
        o[i] = p[i];
}

void mutate(chromo c) {
    int m, mut = min(MUTRATE, N / 2);
    for (m=0; m<mut; m++) {
        idx_t i = rnd(N);
        idx_t j = (i + rnd(N)) % N;
        idx_t tmp = c[i];
        c[i] = c[j];
        c[j] = tmp;
    }
    mut = HEXSPINRATE;
    for (m=0; m<mut; m++) {
        idx_t i = rnd(2*(B-A)+1),
              j = rnd(B - abs(B-A - i)),
              *ij = idx[i][j],
              k, d = rnd(5) + 1;
        static idx_t tmp[6];
        for (k=0; k<6; k++)
            tmp[(k+d)%6] = c[ij[k]];
        for (k=0; k<6; k++)
            c[ij[k]] = tmp[k];
    }
}

void repair(chromo c) {
    idx_t used[N] = {0}, dupl[N] = {0},
          dups = 0, i,j,k;
    short d = rnd(N);
    for (i=0; i<N; i++) {
        k = (i + d) % N;
        j = c[k] - 1;
        if (used[j] > 0) {
            dupl[k] = 1;
            dups++;
        } else
            used[j]++;
    }
    for (i=0, k=0; i<N && k<dups; i++)
        if (dupl[i]) {
            // find unused, repair, mark used
            // TODO: try to choose unused more randomly
            d = rnd(dups);
            while (d >= 0) {
                while (used[j])
                    j = (j + 1) % N;
                d--;
            }
            c[i] = j + 1;
            used[j] = 1;
            k++;
        }
    return;
#if 0
    idx_t i, ones = 0;
    idx_t diff;
    for (i=0; i<N; i++)
        if (c[i] == 1)
            ones++;
    diff = N - 2 * ones;
    if (abs(diff) > 1) {
        gene more = diff < 0 ? 1 : 0;
        idx_t to_flip = abs(N / 2 - ones);
        ones = max(ones, N - ones);
        idx_t o, j, k, d = max(ones / to_flip, 2) - 1;
        for (o=0, j=0, i=0, k=0; k<to_flip && o<ones; j++) {
            j += rnd(d);
            for (; i<N; i++)
                if (c[i] == more) {
                    if (o == j) {
                        c[i] = 1 - c[i];
                        k++;
                        i++;
                        break;
                    }
                    o++;
                }
        }
    }
#endif
}




/****************************************************************************
 * Genetic Algorithm                                                        *
 ****************************************************************************/

#define ff(f) ((f - fworst) + (fbest - fworst) / (SELPRESS - 1))
inline void evaluate(int n) {
    /* calculate variance, mean, fitness, etc. */
    chromo c = pop[n];
    int s, sum = 0, sqsum = 0;
    idx_t i,j,C; char L,H;
    for_each_ij {
        s = hexsum(c,i,j);
        sum += s;
        sqsum += s*s;
    }
    fitness_t mean = (fitness_t)sum / M,
              meansq = (fitness_t)sqsum / M,
              var = meansq - mean*mean,
              fitness = mean - sqrt(var * N);
    /* now, update */
    /* NOTE: We don't need a critical region here
     * since each n allocated to a thread is distinct. */
    fitness_t oldf = popf[n], oldmean = popmean[n], oldvar = popvar[n];
    popf[n] = fitness;
    popvar[n] = var;
    popmean[n] = mean;
    fsum += fitness - oldf;
    varsum += var - oldvar;
    meansum += mean - oldmean;
    if (fbest < fitness) {
        fbest = fitness;
        fbestmean = mean;
        fbestvar = var;
        fbestidx = n;
    }
    if (fworst > fitness)
        fworst = fitness;
    if (var == 0) {
        var0cnt++;
        if (var0cnt == 1 || popf[var0idx] < fitness)
            var0idx = n;
    }
    if (oldvar == 0)
        var0cnt--;
}

inline int pick() {
    fitness_t s = 0, pt = rnd_f(ffsum);;
    int i;
    for (i=0; i<P; i++) {
        s += ff(popf[i]);
        if (s > pt)
            return i;
    }
    return rnd(P);
}

inline void generate_offspring(int n) {
    /* select parents */
    int p1, p2;
    p1 = pick();
    do {
        p2 = pick();
    } while (p1 == p2);
    /* and generate offspring */
    chromo o = offspring[n];
    xover(pop[p1], pop[p2], o);
    repair(o);
    mutate(o);
    parent1[n] = p1;
    parent2[n] = p2;
}

void initialize_population() {
    int n;
    pop = malloc(P * sizeof(chromo));
    for (n=0; n<P; n++) {
        chromo c = new_chromosome();
        idx_t i;
        for (i=0; i<N; i++)
            c[i] = 1+rnd(N); // TODO: better random assignment: assign each only once
        mutate(c);
        repair(c);
        pop[n] = c;
        evaluate(n);
    }
}

inline void replace_population() {
    int n;
    for (n=0; n<K; n++) {
        int p1 = parent1[n];
        int p2 = parent2[n];
        int p = (popf[p1] > popf[p2]) ? p2 : p1;
        copy_chromosome(pop[p], offspring[n]);
        evaluate(p);
    }
}

inline void begin_generation() {
    int n;
    ffsum = 0;
    for (n=0; n<P; n++)
        ffsum += ff(popf[n]);
}
inline void end_generation() {
    generations++;
    gbestrepeated = (gbest == fbest) ? gbestrepeated + 1 : 1; 
    gbest = fbest;
}

#ifdef MULTITHREAD
#include <pthread.h>

#ifndef NUMTHREADS
#define NUMTHREADS 4
#endif

pthread_mutex_t generated_mtx = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t generate_new_cond = PTHREAD_COND_INITIALIZER,
               generation_ready_cond = PTHREAD_COND_INITIALIZER;
int generated = 0;

void *offspring_generator(void *p) {
    int n;
    pthread_mutex_lock(&generated_mtx);
    for (;;) {
        pthread_cond_wait(&generate_new_cond, &generated_mtx);
        if (generated < K) {
            n = generated++;
            pthread_mutex_unlock(&generated_mtx);
            generate_offspring(n);
            pthread_mutex_lock(&generated_mtx);
            if (generated == K)
                pthread_cond_signal(&generation_ready_cond);
            else
                pthread_cond_broadcast(&generate_new_cond);
        }
    }
    pthread_mutex_unlock(&generated_mtx);
    return NULL;
}

inline void generate_offsprings() {
    generated = 0;
    pthread_cond_broadcast(&generate_new_cond);
    pthread_cond_wait(&generation_ready_cond, &generated_mtx);
}

#define GA() \
    pthread_mutex_trylock(&generated_mtx); \
    ga(); \
    pthread_mutex_unlock(&generated_mtx)

#else
inline void generate_offsprings() {
    int n;
    for (n=0; n<K; n++)
        generate_offspring(n);
}

#define GA() ga()

#endif

void ping(int x) {
    fprintf(stderr, "%d: pop m=%f v=%f f=%f; best m=%f v=%f f=%f\n",
            generations, meansum / P, varsum / P, fsum / P,
            fbestmean, fbestvar, fbest);
}

void ga() {
    while (! DONE) {
        begin_generation();
        generate_offsprings();
        replace_population();
        end_generation();
    }
}

void status(int x) {
    FILE *out = (x == SIGQUIT) ? stderr : stdout;
    fprintf(out, "generation #%d: pop v=%f f=%f\n",
            generations, varsum / P, fsum / P);
    /* find best */
    int n, b = 0;
    fitness_t f = popf[b];
    for (n=1; n<P; n++)
        if (popf[n] > f) {
            f = popf[n];
            b = n;
        }
debug("mutrate=%d, hexspinrate=%d\n", MUTRATE, HEXSPINRATE);
    fprintf(out, "best(%d) sum=%8.5f var=%8.5f fitness=%8.5f\n\n",
            gbestrepeated, popmean[b], popvar[b], popf[b]);
    print_chromo(out, pop[b]);
    /* if solution was found show it */
    if (var0cnt > 0 && var0idx != b && var0idx != -1) {
        n = var0idx;
        fprintf(out, "sum=%f var=%f\n\n", popmean[n], popvar[n]); \
        print_chromo(out, pop[n]);
    }
}

struct timezone tz;
struct timeval tbegin, tend;
void die(int x) {
    gettimeofday(&tend, &tz);
    struct rusage usage;
    if (getrusage(RUSAGE_SELF, &usage) >= 0) {
#define tdiff(s, t) \
	(float)(t.tv_sec - s.tv_sec) + (float)(t.tv_usec - s.tv_usec) * 1e-6
#define ptime(t) printf("%fs", (float)t.tv_sec + (float)t.tv_usec * 1e-6)
	printf("execution time:");
	printf(" real %fs", tdiff(tbegin, tend));
	printf(" user ");
	ptime(usage.ru_utime);
	printf(" sys ");
	ptime(usage.ru_stime);
	printf("\n");
    }
    ping(x);
    status(x);
    exit(x);
}




int main(int argc, char *argv[]) {
    srand((int)argv);
    gettimeofday(&tbegin, &tz);

    alarm(T);
    signal(SIGALRM, die);
    signal(SIGHUP,  die);
    signal(SIGTERM, die);
    signal(SIGINT,  ping);
    signal(SIGQUIT, status);

    fill_idx();
    int n;
    for (n=0; n<K; n++)
        offspring[n] = new_chromosome();
    for (n=0; n<P; n++)
        popvar[n] = 1;
    initialize_population();
    debug("memory, data ready\n");

#ifdef MULTITHREAD
    int thr_id[NUMTHREADS];
    pthread_t threads[NUMTHREADS];
    for (n=0; n<NUMTHREADS; n++) {
        thr_id[n] = n;
        pthread_create(&threads[n], NULL,
                offspring_generator, (void *)&thr_id[n]);
    }
    debug("threads ready\n");
#endif

    message("starting GA\n");
    ping(0);
    GA();
    die(0);
    return -1;
}
